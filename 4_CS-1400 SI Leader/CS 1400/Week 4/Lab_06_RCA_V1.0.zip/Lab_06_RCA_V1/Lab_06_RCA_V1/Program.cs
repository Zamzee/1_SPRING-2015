﻿// Project Prolog
// Name: Russell C. Andlauer
// CS 1400 
// Project: CS1400_Lab_06
// Date: 6/3/2014
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    /// <summary>
    /// Purpose: Entry point to your C# program
    /// </summary>
    static void Main()
    {

        Console.WriteLine("Press Enter to continue ...");
        Console.ReadLine();

        //1) Ask User how many Pirates are on board. (?)

        //2) Get the User's Input and Save it as TotalCrew (int)

        //3) Ask the User how much Gold has been collected. (?)

        //4) Get the User's Input and Save it as TotalGold (int)

        //5) Count TotalGold

        //6) Multiply TotalCrew by 3 and Save it as TotalPay (int)

        //7) Get TotalPay

        //8) Get TotalGold

        //9) Subtract TotalPay from TotalGold

        //10) Multiply TotalGold by 0.12 and Save result as Cap'n_Share (int)

        //11) Subtract Cap'n_Share from TotalGold

        //12) Multiply TotalGold by .08 and Save results as 1st_Mate_Share (int)

        //13) Subtract 1st_Mate_Share from TotalGold

        //14) Count TotalGold

        //15) Divide TotalGold by TotalCrew and Save as Crew_Cut (int)

        //16) Save remainder as PBA_Fee (int)

        //16) Print result "Each crew member gets {0} pieces of Gold.  The PBA gets {1} pieces of Gold for Union Fees.", CrewCut, PBA;

    }//End Main()
}//End class Program
