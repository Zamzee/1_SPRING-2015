﻿// The Token Machine
//  Name: Laarni A Sutton
//  Course and Section:  CS 1400 - X01
//  Project: Lab 13
//  Date: 06/26/2014

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS1400_Lab13
{
    // The TokenMachine class
    class TokenMachine
    {

        // The the default data members of the class
        private const int HUNDRED = 100;
        private const int ZERO = 0;
        int tokens = HUNDRED;
        int quarters = ZERO;

        // The default constructor
        // Purpose:  It resets all the declared values for tokens and quarters
        // Parameters:  None
        // Returns:  None
        public void Reset()
        {
            tokens = HUNDRED;
            quarters = ZERO;
        }

        // The GetToken method
        // Purpose:  To reduce tokens and incrase quarters by one
        // Parameters:  Interger for tokens and quarters
        // Returns:  None
        public void GetToken()
        {
            tokens = --tokens;
            quarters = ++quarters;
        }

        // The CountTokens method
        // Purpose:  To display the number of the tokens in the machine
        // Paramters:  The new token value
        // Returns:  An interger for tokens
        public int CountTokens()
        {
            return tokens;
        }

        // The CountQuarters method
        // Purpose:  To display the number of quarters that are in the machine
        // Parameters:  The new quarter value
        // Returns:  An internet for quarters
        public int CountQuarters()
        {
            return quarters;
        }

    }
}
