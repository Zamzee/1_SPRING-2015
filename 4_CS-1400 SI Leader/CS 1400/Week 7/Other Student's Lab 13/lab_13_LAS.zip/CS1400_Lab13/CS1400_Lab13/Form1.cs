﻿//  File Prologue
//  Name: Laarni A Sutton
//  Course and Section:  CS 1400 - X01
//  Project: Lab 13
//  Date: 06/26/2014

//  I declare that the following code was written by me or provided 
//  by the instructor for this project. I understand that copying source
//  code from any other source constitutes cheating, and that I will receive
//  a zero on this project if I am found in violation of this policy.
 
// ---------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS1400_Lab13
{
    public partial class Form1 : Form
    {
        // A class level reference to a token machine
        private TokenMachine tm;

        public Form1()
        {
            InitializeComponent();

            // Create a token machine object
            tm = new TokenMachine();
            tm.Reset(); 

        }
        
        // The exitToolStripMenuItem1 method
        // Purpose:  To terminate the program
        // Parameters:  The object generating the event and the event arguments
        // Returns:  None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // The aboutToolStripeMenuItem method
        // Purpose:  To display strings in a message box
        // Parameters:  The object generating the event and the event arguments
        // Returns:  None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("- Laarni A Sutton\n- CS 1400\n- Lab 13", "The Token Machine");
        }

        // The button1 or getTokenTxt method
        // Purpose:  To reduce tokens and increase quarters by one
        // Parameters:  The object generating the event and the event arguments
        // Returns:  None
        private void button1_Click(object sender, EventArgs e)
        {
            // Get data from Token Machine class
            int remTokens = int.Parse(tokensTxt.Text); ;
            int remQuarters = int.Parse(quartersTxt.Text); ;

            // Create strings for tokens and quarters
            string tokens = string.Format("{0}", --remTokens);
            string quarters = string.Format("{0}", ++remQuarters);

            // Show strings in tokens and quarters text boxes
            tokensTxt.Text = tokens;
            quartersTxt.Text = quarters;

        }
        
        // The resetAll Method
        // Purpose:  To return the values of tokens:0 and quarters:100
        // Parameters:  The object generating the event and the event arguments
        // Returns:  None
        private void resetAll_Click(object sender, EventArgs e)
        {
            tm.Reset();
            int redoTokens = tm.CountTokens();
            int redoQuarters = tm.CountQuarters();
            string resetTokens = string.Format("{0}", redoTokens);
            string resetQuarters = string.Format("{0}", redoQuarters);
            tokensTxt.Text = resetTokens;
            quartersTxt.Text = resetQuarters;
        }
    }
}
