﻿// Name: Stephanie Gilchrist 
// Class: CS1400 Section X01
// Assignment: Lab #13: Token Machine
// Date: June 26, 2014

// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

// Program Objective: Design an application that calculates the total amount
// of tokens and quarters left in a token counter as one quarter is put in
// and one token comes out.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practiceLab13
{
    public partial class Form1 : Form
    {
        
        // A class level reference to a token machine
        private TokenMachine tm;

        public Form1()
        {
            InitializeComponent();

            // create a token machine object
            tm = new TokenMachine();
            refreshForm();
        }

       // The getToken button method
       // Purpose: to call the GetToken method in the token machine class
       // and to update the display in the textboxes
       // Parameters the sending object and the event arguments
       // Returns: two intgers, the token and quarter numbers
        private void getTokenBtn_Click(object sender, EventArgs e)
        {
            tm.GetToken();
            refreshForm();
        }
       
        // The resetBtn_Click Method
        // Purpose: To clear the text in textboxes
        // Parameters: The object gererating the event and the event arguments
        // Returns: None
        private void resetBtn_Click(object sender, EventArgs e)
        {
            tm.Reset();
            refreshForm();
        }

        // The exitToolStripMenuItem1 Method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        // The aboutToolStripMenuItem Method
        // Purpose: To display a message box with the provided string of information
        // Parameters: The object generating the event and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Stephanie Gilchrist\nCS1400\nLab #13\nToken Machine");
        }

        // The refreshForm Method
        // Purpose: To update the textboxes with the most current results to the
        // most current action made
        // Parameters: The opject generating the event and the event arguments
        // Returns: None
        public void refreshForm()
        {
            quarterTxt.Text = tm.CountQuarters().ToString();
            tokenTxt.Text = tm.CountTokens().ToString();
        }
    }
}
