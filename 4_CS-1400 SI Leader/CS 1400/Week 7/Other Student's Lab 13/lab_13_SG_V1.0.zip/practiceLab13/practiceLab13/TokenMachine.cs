﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practiceLab13
{
 
    // The TokenMachine class 
    class TokenMachine
    {
       const int TOTAL_TOKENS = 100;

        // The data members of the class
        private int numToken;
        private int numQuarter;

        public TokenMachine()
        {
            numToken = TOTAL_TOKENS;
            numQuarter = 0;
        }
   

        // The GetToken Method
        // Purpose: to calculate the increase/decrease of quarters & tokens
        // Parameters: int numToken, int numQuarter
        // Returns: none
        public void GetToken()
        {
            numToken--;
            numQuarter++;
        }

        // The CountTokens Method
        // Purpose: to return the amount of Tokens
        // Parameters: None
        // Returns: an integer amount of tokens
        public int CountTokens()
        {
            return numToken;
        }

        // The CountQuarters Method
        // Purpose: to return the amount of Quarters
        // Parameters: None
        // Returns: an integer amount of quarters
        public int CountQuarters()
        {
            return numQuarter;
        }

        // The Reset Method
        // Purpose: to reset the amount of quarters to 0 and tokens to 100
        // Parameters: None
        // Returns: None
        public void Reset()
        {
            numQuarter = 0;
            numToken = TOTAL_TOKENS;
        }
   }
}
