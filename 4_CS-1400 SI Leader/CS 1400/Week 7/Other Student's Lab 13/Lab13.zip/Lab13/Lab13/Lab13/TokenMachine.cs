﻿// File Prologue
// Name: Charlie Barber
// Class: CS 1400 - X01
// Project: Lab 13
// Date: 6/26/2014
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13
{
    class TokenMachine
    {
        const int ONE_HUNDRED = 100;

        //Private data members
        private int numOfQuarters = 0;
        private int numOfTokens = 0;

        //Default Constructor
        //Purpose: To initialize the starting values
        //Parameters: None
        //Returns: Nothing
        public TokenMachine()
        {
            numOfQuarters = 0;
            numOfTokens = 0;
        }

        //Parametereized Constructor
        //Purpose: To give values to the data members
        //Parameters: Two int
        //Returns: Nothing
        public TokenMachine(int numQuarters, int numTokens)
        {
            numOfQuarters = numQuarters;
            numOfTokens = numTokens;
        }

        //----------Getters----------------

        //GetNumOfQuarters Method
        //Purpose: To get the number of quarters
        //Parameters: None
        //Returns: An int
        public int GetNumOfQuarters()
        {
            return numOfQuarters;
        }

        //GetNumOfTokens Method
        //Purpose: To get the number of tokens
        //Parameters: None
        //Returns: An int
        public int GetNumOfTokens()
        {
            return numOfTokens;
        }

        //Reset Method
        //Purpose: To reset all of the numbers back to the starting numbers
        //Parameters: None
        //Returns: Nothing
        public void Reset()
        {
            numOfQuarters = 0;
            numOfTokens = ONE_HUNDRED;
           
        }

        //Get Token Method
        //Purpose: To decrease tokens by one and increase quarters by one
        //Parameters: None
        //Returns: Nothing
        public void GetToken()
        {
            numOfTokens -= 1;
            numOfQuarters += 1;
            
        }
    }
}
