﻿// File Prologue
// Name: Charlie Barber
// Class: CS 1400 - X01
// Project: Lab 13
// Date: 6/26/2014
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab13
{
    public partial class Form1 : Form
    {
        //A class reference to the TokenMachine
        private TokenMachine newTokenMachine;

        public Form1()
        {
            InitializeComponent();
            //Creating a new TokenMachine object
            newTokenMachine = new TokenMachine();
            newTokenMachine.Reset();
        }


        //ExitToolStripMenuItem1_Click
        //Purpose: To close the application when clicked
        //Parameters: The sending object and the event arguments
        //Returns: nothing
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //AboutToolStripMenuItem1_Click
        //Purpose: To display student information
        //Parameters: The sending object and the event arguments
        //Returns: nothing
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Charlie Barber\nCS 1400-X01\nLab 13");

        }

        //Reset Button Click
        //Purpose: To reset the data back to the beginning numbers
        //Parameters: The sending object and the event arguments
        //Returns: nothing
        private void button2_Click(object sender, EventArgs e)
        {
            //Call Reset method
            newTokenMachine.Reset();

            //Get the number of quarters and tokens and save them in a variable
            int newTokenValue = newTokenMachine.GetNumOfTokens();
            int newQuarterValue = newTokenMachine.GetNumOfQuarters();

            //Change the values to strings
            string strNewQuartValue = String.Format("{0:d}", newQuarterValue);
            string strNewTokenValue = String.Format("{0:d}", newTokenValue);
            //Display them in the appropriate text boxes
            numQuartTxtBox.Text = strNewQuartValue;
            numTokensTxtBox.Text = strNewTokenValue;

        }

        //GetToken Button Click
        //Purpose: To get a token and decrement the Token box by one and increment the Quarter box by one
        //Parameters: The sending object and the event arguments
        //Returns: nothing
        private void button1_Click(object sender, EventArgs e)
        {
            //Change the numbers from the text boxes into int
            int tokenValue = int.Parse(numTokensTxtBox.Text);
            int quarterValue = int.Parse(numQuartTxtBox.Text);

            //Create a new object with the values from the boxes
            newTokenMachine = new TokenMachine(quarterValue, tokenValue);

            //Decrease the value by one on the tokens and increase by one on the quarters
            newTokenMachine.GetToken();

            int newTokenValue = newTokenMachine.GetNumOfTokens();
            int newQuarterValue = newTokenMachine.GetNumOfQuarters();

            //Change the values to strings
            string strNewQuartValue = String.Format("{0:d}", newQuarterValue);
            string strNewTokenValue = String.Format("{0:d}", newTokenValue);
            //Display them in the appropriate text boxes
            numQuartTxtBox.Text = strNewQuartValue;
            numTokensTxtBox.Text = strNewTokenValue;
        }

        
        private void numQuartTxtBox_TextChanged(object sender, EventArgs e)
        {
        }
        private void numTokensTxtBox_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
