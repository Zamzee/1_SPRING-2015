﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

numOne = int.Parse(txtNumOne.Text);
numTwo = int.Parse(txtNumTwo.Text);
string txtNumOne = string.Format("{0D}", num);
string txtNumTwo = string.Format("{0D}", num); 
namespace Project_1_RCA_V1._0
{
   
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    
        }
        /// <summary>THe ToolStripMenuItem2 method
        /// Purpose: To show an about information window
        /// </summary>
        /// <param name="sender"></param>The object generating the event and the event arguments
        /// <param name="e"></param>
        
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Russell C. Andlauer\nCS-1400\nProject 01");
        }
       
        /// <summary> The exitToolStripMenuItem1 method
        /// Purpose: To close the window and terminate the application
        /// </summary>
        /// <param name="sender"></param>The object generating the event and the event arguments
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string txtNumOne = string.Format("{0D}", num);
            int numOne = int.Parse(txtNumOne.Text);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
         double sum = numOne + numTwo;
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            double diff = numOne - numTwo;
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            double prod = numOne * numTwo;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            double quot = numOne / numTwo;
        }

        private void txtNumTwo_TextChanged(object sender, EventArgs e)
        {
            string txtNumTwo = string.Format("{0D}", num);
            numTwo = int.Parse(txtNumTwo.Text);
        }
    }
}
