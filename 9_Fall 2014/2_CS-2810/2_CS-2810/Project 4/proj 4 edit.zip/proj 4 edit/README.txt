Hey, all you guys have to do is:
- put your names in the .STRINGZ in the bottom and -fill out the description, your name, and type your name by the academic honesty statement at the top of the program before the code starts. 
- Assemble it to make sure it works. 
- Make sure to rename the .asm (P4_your_initials). 
- You only have to submit the .asm file.  

-Good luck on your Finals, don't be a trap x22!