/////////////////////////////////////////
// File Prologue
// Author: Russell Andlauer
// Class: CS-2420-601
// Project: Program 2 - Linked Lists
// Date Last Modified: February 5th, 2015
/////////////////////////////////////////
#include "DoubleList.h"


DoubleList::DoubleList()
{
}

DoubleList::DoubleList(SingleList n)
{
	// Node* Cursor = n->head
	// else 
	// if (cursor->dataNum < doubleHead


}

DoubleList::~DoubleList()
{
}
